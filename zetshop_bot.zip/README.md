# ZetShopUz Telegram Bot

A Telegram bot for managing an online shop, built with aiogram 3.19.0.

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file with your configuration:
```
BOT_TOKEN=your_bot_token_here
DATABASE_URL=postgresql://username:password@localhost:5432/zetshop
```

## Running the Bot

### Development Mode
```bash
python bot.py
```

### Production Mode (with auto-restart)
```bash
python persistent_bot.py
```

## Features

- Product catalog with categories
- Shopping cart functionality
- Order management
- Admin panel for managing products and orders
- Persistent storage with PostgreSQL
- Automatic restart and health monitoring

## Project Structure

- `bot.py` - Main bot implementation
- `keyboards.py` - Telegram keyboard layouts
- `persistent_bot.py` - Production runner with monitoring
- `export_database.py` - Database export utilities
- `requirements.txt` - Project dependencies
