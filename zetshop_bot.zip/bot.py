import os
import logging
from datetime import datetime
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from dotenv import load_dotenv
from database import Database

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=os.getenv('BOT_TOKEN'))
storage = MemoryStorage()
dp = Dispatcher(storage=storage)
router = Router()
dp.include_router(router)

# Initialize database
db = Database(os.getenv('DATABASE_URL'))

# Define states
class UserState(StatesGroup):
    browsing = State()
    cart = State()
    checkout = State()
    order_history = State()

class AdminState(StatesGroup):
    main = State()
    add_product = State()
    edit_product = State()
    confirm_delete = State()
    add_category = State()

# Admin commands
@router.message(Command('admin'))
async def admin_command(message: Message, state: FSMContext):
    user_id = str(message.from_user.id)
    admin_id = os.getenv('ADMIN_USER_ID')
    
    if not admin_id:
        # First user to use /admin becomes admin
        os.environ['ADMIN_USER_ID'] = user_id
        with open('.env', 'a') as f:
            f.write(f'ADMIN_USER_ID={user_id}\n')
        await message.answer('You are now the admin!')
    elif user_id != admin_id:
        await message.answer('You are not authorized to use admin commands.')
        return
    
    await state.set_state(AdminState.main)
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton('📦 Add Product'),
        KeyboardButton('🗂 Add Category')
    )
    keyboard.add(
        KeyboardButton('📋 View Orders'),
        KeyboardButton('❌ Exit Admin')
    )
    await message.answer('Welcome to admin panel!', reply_markup=keyboard)

# Add product handlers
@router.message(F.text == '📦 Add Product', StateFilter(AdminState.main))
async def add_product_start(message: Message, state: FSMContext):
    categories = db.get_categories()
    if not categories:
        await message.answer('Please add a category first!')
        return
    
    markup = InlineKeyboardMarkup(row_width=2)
    for category in categories:
        markup.add(InlineKeyboardButton(
            text=category.name,
            callback_data=f'add_product_cat_{category.id}'
        ))
    
    await state.set_state(AdminState.add_product)
    await message.answer('Select category for the new product:', reply_markup=markup)

@router.message(F.text == '🗂 Add Category', StateFilter(AdminState.main))
async def add_category_start(message: Message, state: FSMContext):
    await state.set_state(AdminState.add_category)
    await message.answer('Please send the name for the new category:')

@router.message(F.text == '📋 View Orders', StateFilter(AdminState.main))
async def view_orders(message: Message):
    orders = db.get_all_orders()
    if not orders:
        await message.answer('No orders found.')
        return
    
    for order in orders:
        user = db.get_user(order.user.telegram_id)
        status_emoji = {
            'pending': '⏳',
            'confirmed': '✅',
            'cancelled': '❌',
            'completed': '🎉'
        }.get(order.status, '❓')
        
        items_text = '\n'.join(
            f'- {item.product.name} x{item.quantity} = ${item.price * item.quantity:.2f}'
            for item in order.items
        )
        
        markup = InlineKeyboardMarkup(row_width=2)
        if order.status == 'pending':
            markup.add(
                InlineKeyboardButton('✅ Confirm', callback_data=f'order_confirm_{order.id}'),
                InlineKeyboardButton('❌ Cancel', callback_data=f'order_cancel_{order.id}')
            )
        
        await message.answer(
            f'Order #{order.id} ({status_emoji} {order.status})\n'
            f'Customer: {user.first_name} (@{user.username})\n'
            f'Date: {order.created_at.strftime("%Y-%m-%d %H:%M")}\n'
            f'\nItems:\n{items_text}\n'
            f'\nTotal: ${order.total_amount:.2f}\n'
            f'Delivery Address: {order.delivery_address}',
            reply_markup=markup
        )

# Regular user commands
@router.message(Command('start'))
async def start_command(message: Message, state: FSMContext):
    user = db.get_user(message.from_user.id)
    if not user:
        user = db.create_user(
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name
        )
    
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(
        KeyboardButton('🏪 Catalog'),
        KeyboardButton('🛒 Cart')
    )
    keyboard.add(
        KeyboardButton('📜 My Orders'),
        KeyboardButton('ℹ️ Help')
    )
    
    await state.set_state(UserState.browsing)
    await message.answer(
        f'Welcome to our shop, {message.from_user.first_name}!\n'
        'Use the buttons below to navigate.',
        reply_markup=keyboard
    )

@router.message(Command('orders'))
async def orders_command(message: Message, state: FSMContext):
    user = db.get_user(message.from_user.id)
    if not user:
        await message.answer('Please start the bot first with /start')
        return
    
    orders = db.get_user_orders(user.id)
    if not orders:
        await message.answer('You have no orders yet.')
        return
    
    await state.set_state(UserState.order_history)
    for order in orders:
        status_emoji = {
            'pending': '⏳',
            'confirmed': '✅',
            'cancelled': '❌',
            'completed': '🎉'
        }.get(order.status, '❓')
        
        items_text = '\n'.join(
            f'- {item.product.name} x{item.quantity} = ${item.price * item.quantity:.2f}'
            for item in order.items
        )
        
        await message.answer(
            f'Order #{order.id} ({status_emoji} {order.status})\n'
            f'Date: {order.created_at.strftime("%Y-%m-%d %H:%M")}\n'
            f'\nItems:\n{items_text}\n'
            f'\nTotal: ${order.total_amount:.2f}\n'
            f'Delivery Address: {order.delivery_address}'
        )

# Catalog handlers
@router.message(F.text == '🏪 Catalog')
async def show_catalog(message: Message):
    categories = db.get_categories()
    if not categories:
        await message.answer('No categories available yet.')
        return
    
    markup = InlineKeyboardMarkup(row_width=2)
    for category in categories:
        markup.add(InlineKeyboardButton(
            text=category.name,
            callback_data=f'category_{category.id}'
        ))
    
    await message.answer('Choose a category:', reply_markup=markup)

@router.callback_query(F.data.startswith('category_'))
async def show_category_products(callback: CallbackQuery):
    category_id = int(callback.data.split('_')[1])
    products = db.get_products(category_id=category_id)
    
    if not products:
        await callback.message.answer('No products in this category.')
        return
    
    for product in products:
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(
            text='🛒 Add to Cart',
            callback_data=f'add_to_cart_{product.id}'
        ))
        
        await callback.message.answer_photo(
            photo=product.image_url or 'https://via.placeholder.com/400',
            caption=(
                f'{product.name}\n'
                f'Price: ${product.price:.2f}\n\n'
                f'{product.description or "No description"}'
            ),
            reply_markup=markup
        )
    
    await callback.answer()

# Error handler
@router.error()
async def error_handler(event: types.ErrorEvent, state: FSMContext):
    logging.error(f'Error: {event.exception}', exc_info=True)
    await event.update.message.answer(
        'Sorry, something went wrong. Please try again or contact support.'
    )

# Start the bot
async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
