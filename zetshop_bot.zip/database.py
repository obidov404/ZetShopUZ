from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from models import Base, User, Category, Product, Order, OrderItem

class Database:
    def __init__(self, database_url):
        self.engine = create_engine(database_url)
        Base.metadata.create_all(self.engine)
        session_factory = sessionmaker(bind=self.engine)
        self.Session = scoped_session(session_factory)

    def get_session(self):
        return self.Session()

    # User operations
    def get_user(self, telegram_id):
        with self.get_session() as session:
            return session.query(User).filter_by(telegram_id=telegram_id).first()

    def create_user(self, telegram_id, username=None, first_name=None, last_name=None):
        with self.get_session() as session:
            user = User(
                telegram_id=telegram_id,
                username=username,
                first_name=first_name,
                last_name=last_name
            )
            session.add(user)
            session.commit()
            return user

    # Category operations
    def get_categories(self):
        with self.get_session() as session:
            return session.query(Category).all()

    def add_category(self, name, description=None):
        with self.get_session() as session:
            category = Category(name=name, description=description)
            session.add(category)
            session.commit()
            return category

    # Product operations
    def get_products(self, category_id=None):
        with self.get_session() as session:
            query = session.query(Product)
            if category_id:
                query = query.filter_by(category_id=category_id)
            return query.all()

    def add_product(self, name, price, category_id, description=None, image_url=None):
        with self.get_session() as session:
            product = Product(
                name=name,
                price=price,
                category_id=category_id,
                description=description,
                image_url=image_url
            )
            session.add(product)
            session.commit()
            return product

    def update_product(self, product_id, **kwargs):
        with self.get_session() as session:
            product = session.query(Product).get(product_id)
            if product:
                for key, value in kwargs.items():
                    setattr(product, key, value)
                session.commit()
            return product

    def delete_product(self, product_id):
        with self.get_session() as session:
            product = session.query(Product).get(product_id)
            if product:
                session.delete(product)
                session.commit()
                return True
            return False

    # Order operations
    def create_order(self, user_id, items, delivery_address, notes=None):
        with self.get_session() as session:
            order = Order(
                user_id=user_id,
                delivery_address=delivery_address,
                notes=notes
            )
            session.add(order)
            
            total_amount = 0
            for product_id, quantity in items:
                product = session.query(Product).get(product_id)
                if product:
                    order_item = OrderItem(
                        order=order,
                        product=product,
                        quantity=quantity,
                        price=product.price
                    )
                    session.add(order_item)
                    total_amount += product.price * quantity
            
            order.total_amount = total_amount
            session.commit()
            return order

    def get_user_orders(self, user_id):
        with self.get_session() as session:
            return session.query(Order).filter_by(user_id=user_id).all()

    def update_order_status(self, order_id, status):
        with self.get_session() as session:
            order = session.query(Order).get(order_id)
            if order:
                order.status = status
                session.commit()
            return order

    def get_all_orders(self, status=None):
        with self.get_session() as session:
            query = session.query(Order)
            if status:
                query = query.filter_by(status=status)
            return query.all()
