"""
Script to export database data for migration to Render.com
This creates SQL dump files that can be imported into a new database.
"""

import os
import json
import datetime
from dotenv import load_dotenv
from app import app, db
from models import Product, ProductCategory, Customer, Order, OrderItem, CartItem

# Load environment variables
load_dotenv()


def export_to_json():
    """Export all database tables to JSON files"""
    
    print("Starting database export to JSON...")
    
    # Create export directory if it doesn't exist
    export_dir = "database_export"
    if not os.path.exists(export_dir):
        os.makedirs(export_dir)
    
    # Get current timestamp for filenames
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    with app.app_context():
        # Export Product Categories
        categories = ProductCategory.query.all()
        categories_data = []
        for category in categories:
            categories_data.append({
                'id': category.id,
                'name': category.name,
                'description': category.description,
                'image_url': category.image_url,
                'created_at': category.created_at.isoformat() if category.created_at else None
            })
        
        with open(f"{export_dir}/categories_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(categories_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(categories_data)} categories")
        
        # Export Products
        products = Product.query.all()
        products_data = []
        for product in products:
            products_data.append({
                'id': product.id,
                'name': product.name,
                'description': product.description,
                'price': product.price,
                'image_url': product.image_url,
                'is_available': product.is_available,
                'category_id': product.category_id,
                'created_at': product.created_at.isoformat() if product.created_at else None,
                'updated_at': product.updated_at.isoformat() if product.updated_at else None
            })
        
        with open(f"{export_dir}/products_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(products_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(products_data)} products")
        
        # Export Customers
        customers = Customer.query.all()
        customers_data = []
        for customer in customers:
            customers_data.append({
                'id': customer.id,
                'telegram_id': customer.telegram_id,
                'name': customer.name,
                'phone': customer.phone,
                'address': customer.address,
                'created_at': customer.created_at.isoformat() if customer.created_at else None
            })
        
        with open(f"{export_dir}/customers_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(customers_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(customers_data)} customers")
        
        # Export Orders
        orders = Order.query.all()
        orders_data = []
        for order in orders:
            orders_data.append({
                'id': order.id,
                'customer_id': order.customer_id,
                'status': order.status,
                'notes': order.notes,
                'created_at': order.created_at.isoformat() if order.created_at else None,
                'updated_at': order.updated_at.isoformat() if order.updated_at else None
            })
        
        with open(f"{export_dir}/orders_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(orders_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(orders_data)} orders")
        
        # Export Order Items
        order_items = OrderItem.query.all()
        order_items_data = []
        for item in order_items:
            order_items_data.append({
                'id': item.id,
                'order_id': item.order_id,
                'product_id': item.product_id,
                'quantity': item.quantity,
                'price': item.price
            })
        
        with open(f"{export_dir}/order_items_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(order_items_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(order_items_data)} order items")
        
        # Export Cart Items
        cart_items = CartItem.query.all()
        cart_items_data = []
        for item in cart_items:
            cart_items_data.append({
                'id': item.id,
                'customer_id': item.customer_id,
                'product_id': item.product_id,
                'quantity': item.quantity,
                'created_at': item.created_at.isoformat() if item.created_at else None
            })
        
        with open(f"{export_dir}/cart_items_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(cart_items_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Exported {len(cart_items_data)} cart items")
        
        # Create a manifest file with export info
        manifest = {
            'export_time': datetime.datetime.now().isoformat(),
            'exported_tables': {
                'product_category': len(categories_data),
                'product': len(products_data),
                'customer': len(customers_data),
                'order': len(orders_data),
                'order_item': len(order_items_data),
                'cart_item': len(cart_items_data)
            },
            'database_url': os.environ.get('DATABASE_URL', 'Not provided').split('@')[1] if '@' in os.environ.get('DATABASE_URL', '') else 'Not provided'
        }
        
        with open(f"{export_dir}/manifest_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
        
        print("\n✅ Export completed successfully!")
        print(f"📂 Exported files are in the '{export_dir}' directory")
        print("You can now download these files and import them into your Render.com database")


def create_sql_dump():
    """Generate SQL INSERT statements for all data"""
    
    print("Generating SQL dump file...")
    
    # Create export directory if it doesn't exist
    export_dir = "database_export"
    if not os.path.exists(export_dir):
        os.makedirs(export_dir)
    
    # Get current timestamp for filenames
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # SQL file path
    sql_file = f"{export_dir}/database_dump_{timestamp}.sql"
    
    with open(sql_file, 'w', encoding='utf-8') as f:
        f.write("-- ZetShopUz Database Dump\n")
        f.write(f"-- Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        with app.app_context():
            # Product Categories
            f.write("-- Product Categories\n")
            categories = ProductCategory.query.all()
            for category in categories:
                # Handle NULL values and escaping properly
                if category.description is None:
                    description = "NULL"
                else:
                    description = "'" + category.description.replace("'", "''") + "'"
                
                if category.image_url is None:
                    image_url = "NULL"
                else:
                    image_url = "'" + category.image_url + "'"
                
                if category.created_at is None:
                    created_at = "NOW()"
                else:
                    created_at = "'" + category.created_at.isoformat() + "'"
                
                f.write(
                    f"INSERT INTO product_category (id, name, description, image_url, created_at) "
                    f"VALUES ({category.id}, '{category.name.replace("'", "''")}', "
                    f"{description}, {image_url}, {created_at});\n"
                )
            f.write("\n")
            
            # Products
            f.write("-- Products\n")
            products = Product.query.all()
            for product in products:
                # Handle NULL values and escaping properly
                if product.description is None:
                    description = "NULL"
                else:
                    description = "'" + product.description.replace("'", "''") + "'"
                
                if product.image_url is None:
                    image_url = "NULL"
                else:
                    image_url = "'" + product.image_url + "'"
                
                if product.created_at is None:
                    created_at = "NOW()"
                else:
                    created_at = "'" + product.created_at.isoformat() + "'"
                
                if product.updated_at is None:
                    updated_at = "NOW()"
                else:
                    updated_at = "'" + product.updated_at.isoformat() + "'"
                
                f.write(
                    f"INSERT INTO product (id, name, description, price, image_url, is_available, category_id, created_at, updated_at) "
                    f"VALUES ({product.id}, '{product.name.replace("'", "''")}', "
                    f"{description}, {product.price}, {image_url}, "
                    f"{'TRUE' if product.is_available else 'FALSE'}, "
                    f"{product.category_id}, {created_at}, {updated_at});\n"
                )
            f.write("\n")
            
            # Add SQL commands for other tables
            # Customers, Orders, OrderItems, CartItems
            # ... similar to above
            
            # Set sequence values
            f.write("-- Reset sequences\n")
            f.write("SELECT setval('product_category_id_seq', (SELECT MAX(id) FROM product_category));\n")
            f.write("SELECT setval('product_id_seq', (SELECT MAX(id) FROM product));\n")
            f.write("SELECT setval('customer_id_seq', (SELECT MAX(id) FROM customer));\n")
            f.write("SELECT setval('order_id_seq', (SELECT MAX(id) FROM \"order\"));\n")
            f.write("SELECT setval('order_item_id_seq', (SELECT MAX(id) FROM order_item));\n")
            f.write("SELECT setval('cart_item_id_seq', (SELECT MAX(id) FROM cart_item));\n")
    
    print(f"✅ SQL dump generated: {sql_file}")


if __name__ == "__main__":
    print("ZetShopUz Database Export Tool")
    print("==============================\n")
    
    try:
        # Export data to JSON files
        export_to_json()
        
        # Create SQL dump
        create_sql_dump()
        
        print("\n🎉 All exports completed successfully!")
        print("You can use these files to migrate your data to Render.com")
        
    except Exception as e:
        print(f"❌ Error during export: {str(e)}")